import java.io.IOException;

public class Driver 
{

	public static void main(String[] args) throws IOException 
	{
		Scheduler mySched = new Scheduler();
		
		mySched.start();

	}

}
